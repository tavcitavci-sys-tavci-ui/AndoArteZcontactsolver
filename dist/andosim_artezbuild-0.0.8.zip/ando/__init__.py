"""Vendored AndoSim implementation.

This package is included as a dependency of the unified AndoSim ArteZbuild addon.
Registration is handled by the root addon package; this module intentionally does
not register anything by itself.
"""

__all__ = []
